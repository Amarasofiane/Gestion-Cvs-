package beans;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
public class Activity implements Serializable{

	private static final long serialVersionUID = 1L;
	@Id()
    @GeneratedValue(strategy = GenerationType.AUTO)
	Long Id;
	@Basic()
    @Temporal(TemporalType.DATE)
	private Date anne;
	@Basic()
	private String formation;
	@Basic()
	private String titre;
	@Basic(optional = true)
	private String text;
	@Basic(optional = true)
	private String webr;
	
	@ManyToOne(cascade = { CascadeType.MERGE })
	@JoinColumn(name = "owner")
	private Person owner;
	 
	public Activity() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Activity(Date anne�, String formation, String titre, String text, String webr) {
		super();
		this.anne = anne�;
		this.formation = formation;
		this.titre = titre;
		this.text = text;
		this.webr = webr;
	}
	
	public Person getOwner() {
		return owner;
	}
	public void setOwner(Person owner) {
		this.owner = owner;
	}
	public Long getId() {
		return Id;
	}
	public void setId(Long id) {
		Id = id;
	}
	public Date getAnne() {
		return anne;
	}
	public void setAnne(Date anne�) {
		this.anne = anne�;
	}
	public String getFormation() {
		return formation;
	}
	public void setFormation(String formation) {
		this.formation = formation;
	}
	public String getTitre() {
		return titre;
	}
	public void setTitre(String titre) {
		this.titre = titre;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public String getWebr() {
		return webr;
	}
	public void setWebr(String webr) {
		this.webr = webr;
	}
	@Override
	public String toString() {
		return "Activity [anne�=" + getAnne() + ", formation=" + getFormation() + ", titre=" + getTitre() + ", text=" + getText()
				+ ", webr=" + getWebr() + "]";
	}
	
}
