package beans;


import java.io.Serializable;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Embeddable;
import javax.persistence.FetchType;

import javax.persistence.OneToMany;



@Embeddable()
public class Cv implements Serializable {

	private static final long serialVersionUID = 1L;
	private String cvnm;

	 /*  @OneToMany(cascade = { CascadeType.MERGE, CascadeType.PERSIST },
	   fetch = FetchType.LAZY, mappedBy = "owner")
	   private Set<Activity> activitys;
	
	public Set<Activity> getActivitys() {
		return activitys;
	}

	public void setActivitys(Set<Activity> activitys) {
		this.activitys = activitys;
	}*/

	public Cv() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Cv(String cvnm) {
		super();
		this.cvnm = cvnm;
	}

	public String getCvnm() {
		return cvnm;
	}

	public void setCvnm(String cvnm) {
		this.cvnm = cvnm;
	}



	@Override
	public String toString() {
		return "Cv [cvnm=" + getCvnm() + "]";
	}
	
	
}
