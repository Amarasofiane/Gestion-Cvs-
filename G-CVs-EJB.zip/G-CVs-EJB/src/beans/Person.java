package beans;


import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;





@Entity(name = "Person")
@Table(name = "TPerson")
public class Person implements Serializable {
	
	   private static final long serialVersionUID = 1L;
	
    @Id()
    @GeneratedValue(strategy = GenerationType.AUTO)
	Long Id;
    @Basic()
	private String nom;
    @Basic()
	private String prenom;
    @Basic()
	private String email;
    @Basic()
	private String sweb;
    @Basic()
    @Temporal(TemporalType.DATE)
	private Date old;
    @Basic()
	private String pwd;
    @Embedded
    private Cv cvn=new Cv();
    @OneToMany(mappedBy = "owner", cascade = { CascadeType.MERGE, CascadeType.REMOVE })
	private List<Activity> activitys;
	
	public List<Activity> getActivitys() {
		return activitys;
	}
    
	public void add(Activity activity) {
		this.activitys.add(activity);
	}
	
	public void setActivitys(List<Activity> activitys) {
		this.activitys = activitys;
	}
	public Cv getCvn() {
		return cvn;
	}
	public void setCvn(Cv cvn) {
		this.cvn = cvn;
	}
	public Person() {
		super();
	}
	public Person(String nom, String prenom, String email, String sweb, Date old, String pwd) {
		super();
		this.nom = nom;
		this.prenom = prenom;
		this.email = email;
		this.sweb = sweb;
		this.old = old;
		this.pwd = pwd;
	}
	public Long getId() {
		return Id;
	}
	public void setId(Long id) {
		Id = id;
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public String getPrenom() {
		return prenom;
	}
	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getSweb() {
		return sweb;
	}
	public void setSweb(String sweb) {
		this.sweb = sweb;
	}
	public Date getOld() {
		return old;
	}
	public void setOld(Date old) {
		this.old = old;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	@Override
	public String toString() {
		return "Person [Id=" + getId() + ", nom=" + getNom() + ", prenom=" + getPrenom() + ", email=" + getEmail() + ", sweb=" + getSweb()
				+ ", old=" + getOld() + ", pwd=" + getPwd() + "]";
	}
	
	

	

	

}

/*package Beans;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


@Entity(name = "Person")
@Table(name = "TPerson")
public class Person implements Serializable {

   private static final long serialVersionUID = 1L;

   @Id()
   @GeneratedValue(strategy = GenerationType.AUTO)
	Long Id;
   @Basic()
	private String nom;
   @Basic()
	private String prenom;
   @Basic()
	private String email;
   @Basic()
	private String sweb;
   @Basic()
   @Temporal(TemporalType.DATE)
	private Date old;
   @Basic()
	private String pwd;
	
   public Person() {
      super();
   }

public Person( String nom, String prenom, String email, String sweb, Date old, String pwd) {
	super();

	this.nom = nom;
	this.prenom = prenom;
	this.email = email;
	this.sweb = sweb;
	this.old = old;
	this.pwd = pwd;
}

public Long getId() {
	return Id;
}

public void setId(Long id) {
	Id = id;
}

public String getNom() {
	return nom;
}

public void setNom(String nom) {
	this.nom = nom;
}

public String getPrenom() {
	return prenom;
}

public void setPrenom(String prenom) {
	this.prenom = prenom;
}

public String getEmail() {
	return email;
}

public void setEmail(String email) {
	this.email = email;
}

public String getSweb() {
	return sweb;
}

public void setSweb(String sweb) {
	this.sweb = sweb;
}

public Date getOld() {
	return old;
}

public void setOld(Date old) {
	this.old = old;
}

public String getPwd() {
	return pwd;
}

public void setPwd(String pwd) {
	this.pwd = pwd;
}

@Override
public String toString() {
	return "Person [Id=" + Id + ", nom=" + nom + ", prenom=" + prenom + ", email=" + email + ", sweb=" + sweb + ", old="
			+ old + ", pwd=" + pwd + "]";
}


}*/
