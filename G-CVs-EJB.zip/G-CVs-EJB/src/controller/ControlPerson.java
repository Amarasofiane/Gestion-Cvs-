package controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.ejb.Init;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import beans.Activity;
import beans.Cv;
import beans.Person;
import service.SerAuth;
import service.ServiceActivity;
import service.ServicePerson;

@ManagedBean(name = "person")
@SessionScoped
public class ControlPerson {
	
	@EJB
	ServicePerson ser;
	
	@EJB
	ServiceActivity sac;
	
	@EJB
	SerAuth verif;
	
	Person pshow; 
	Person person=new Person();
	
    Activity a1=new Activity();

	String email;
	String psw;
	boolean isAuth=false;
	Person perAuth;

	public Activity getA1() {
		return a1;
	}



	public void setA1(Activity a1) {
		this.a1 = a1;
	}



	@PostConstruct
	public void init(){
		System.out.println("Create " + this);
		if (ser.findAllPersons().size() == 0) {
			Person p1 = new Person();
			p1.setNom("AMARA");
			p1.setPrenom("Sofiane");
			p1.setOld(new Date());
			p1.setEmail("amarasofiane1@gmail.com");
			p1.setSweb("github.com");
			p1.setPwd("marseille2013");
			p1.setCvn(new Cv("D�veloppeur"));
			//p1.setActivitys(ac);
			
			ser.addPerson(p1);
		}
	}
	

	
	 public boolean getIsAuth() {
		return isAuth;
	}

	public void setAuth(boolean isAuth) {
		this.isAuth = isAuth;
	}

	public Person getPerAuth() {
		return perAuth;
	}

	public void setPerAuth(Person perAuth) {
		this.perAuth = perAuth;
	}

	public String getEmail() {
		return email;
	}

	public String getPsw() {
		return psw;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setPsw(String psw) {
		this.psw = psw;
	}
	
	 public Person getPerson() {
		 return person;
	 }

		public Person getPshow() {
			return pshow;
		}

		public void setPshow(Person pshow) {
			this.pshow = pshow;
		}
	 public String inscription() {
		 return"InscriptionJSF";
	 }
	 
	 public String veriauth() {
		 if(verif.Auth(email, psw)) {
				 isAuth=true;
				 perAuth=ser.trouver(email);
				
				 }
	 return "AccueilJSF?faces-redirect=true";
		 
	 }
	 
	 public String add() {
		 ser.addPerson(person);
		 
		 person.setEmail(null);
		 person.setId(null);
		 person.setNom(null);
		 person.setOld(null);
		 person.setPrenom(null);
		 person.setPwd(null);
		 person.setSweb(null);
		 
		 return "AccueilJSF?faces-redirect=true";
	 }
	 public List<Person> findAll(){
		 return ser.findAllPersons();
	 }
	 public String Auth() {
		 return "AuthJSF";
	 }
	 public String Decon() {
		 isAuth=false;
		 return "AccueilJSF?faces-redirect=true";
	 }
	 public String show(long id) {
		 pshow = ser.findPersonByID(id);
		 //System.out.println(pshow.getActivitys()+"  AAAAAAAAA");
		 return "ShowpersonJSF";
	 }
	
	 

	 public String AddAct(long id) {
		 if(getPerAuth().getId()==id) {		 
		 return "AddActivityJSF";
		 }		 
		 return "AccueilJSF?faces-redirect=true";
	 }
	 public String ValiderAc() {
		 a1.setOwner(perAuth);
		 sac.addActivity(a1);
		 a1.setAnne(null);
		 a1.setFormation(null);
		 a1.setId(null);
		 a1.setOwner(null);
		 a1.setText(null);
		 a1.setTitre(null);
		 a1.setWebr(null);
		 return "AccueilJSF?faces-redirect=true";
		 
	 }
	 
	 
	 public List<Activity> getActivity(long p){
		 return sac.findAllActivitys(p);
	 }
	 
	 public String Logout() {
		 long i=00;
		 
		 perAuth.setId(i);
		 perAuth.setEmail(null);
		 perAuth.setNom(null);
		 perAuth.setOld(null);
		 perAuth.setPrenom(null);
		 perAuth.setPwd(null);
		 perAuth.setSweb(null);
		 isAuth=false;
		// perAuth.setCvn(null);
		// perAuth.setActivitys(null);
		 return "AccueilJSF?faces-redirect=true";
	 }
	 public String Modifier() {
		 ser.updatePerson(perAuth);
		 return "AccueilJSF?faces-redirect=true";
	 }
	 public String delete(Person p) {
		 ser.deletePerson(p);
		 long i=00;
		 perAuth.setId(i);
		 perAuth.setEmail(null);
		 perAuth.setNom(null);
		 perAuth.setOld(null);
		 perAuth.setPrenom(null);
		 perAuth.setPwd(null);
		 perAuth.setSweb(null);
		 isAuth=false;
		 return"AccueilJSF";
	 }
}
