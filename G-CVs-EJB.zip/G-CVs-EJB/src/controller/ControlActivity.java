package controller;

import java.util.List;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import beans.Activity;
import beans.Person;
import service.RechPer;
import service.ServiceActivity;

@ManagedBean(name = "ac")
@SessionScoped
public class ControlActivity {
	String type;
	String cle;
	boolean ind=false;

	@EJB
	RechPer pr;
	@EJB
	ServiceActivity srt;
	
	Activity act=new Activity();
	
	public List<Person> finAllbyX(String type,String cle) {
		setInd(true);
		if(type.equals("nom")) {
			return pr.findPersonsBynom(cle);
		}else if(type.equals("prenom")) {
			return pr.findPersonsByprenom(cle);
		}else {
		return pr.findPersonsByAct(cle);
		}
	}



	public String getType() {
		return type;
	}



	public void setType(String type) {
		this.type = type;
	}



	public String getCle() {
		return cle;
	}



	public Activity getAct() {
		return act;
	}



	public void setAct(Activity act) {
		this.act = act;
	}



	public void setCle(String cle) {
		this.cle = cle;
	}

	public boolean getInd() {
		return ind;
	}



	public void setInd(boolean ind) {
		this.ind = ind;
	}

	public String an() {
		 return "AccueilJSF?faces-redirect=true";	

	}
	public String af() {
		return "RechercheTypeJSF";

		 }
	
	public String uptActi(long id) {
        act=srt.findActivityByID(id);
        return "UpdActivityJSF";	      
}
	public String delete(long id) {
		Activity actt=srt.findActivityByID(id);
		srt.removeAct(actt);
		return "AccueilJSF?faces-redirect=true";	
	}
	public String confirmer() {
		srt.updateAct(act);
		return"ShowpersonJSF";
	}
}
