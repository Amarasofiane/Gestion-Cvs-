package service;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import beans.Activity;
import beans.Person;



@Stateless
public class ServicePerson {

    @PersistenceContext(unitName = "myData")
    private EntityManager em;

    @PostConstruct
    public void init() {
        System.out.println("init " + this + " with " + em);
    }

   
    public Person addPerson(Person p) {
        em.persist(p);
        System.err.println("addPerson witdh id=" + p.getId());
        return (p);
    }
    public Person updatePerson(Person p) {
        p = em.merge(p);
        return p;
    }

    public void removePerson(Person p) {
        em.remove(p);
    }
  
    public Person trouver( String email ) {
        Person per = null;
        Query requete = em.createQuery("SELECT u FROM Person u WHERE u.email=:email");
        requete.setParameter( "email", email );
        try {
            per = (Person) requete.getSingleResult();
        } catch ( NoResultException e ) {
            return null;
        } 
        return per;
    }
    
  
  
    public List<Person> findAllPersons() {
        TypedQuery<Person> q = em.createQuery("FROM Person", Person.class);
        return q.getResultList();
    }
    
    public Person findPersonByID(long id) {
    	return em.find(Person.class, id);
    }
    
    public Activity addActivity(Activity act) {
        em.persist(act);
        System.err.println("addActivity witdh id=" + act.getId());
        return (act);
    }
    public void removeAct(Activity act) {
        em.remove(act);
    }
    public Activity updateAct(Activity act) {
        act = em.merge(act);
        return act;
    }
    public void deletePerson(Person person) {
		Person findedPperson = em.find(Person.class, person.getId());
		if (findedPperson != null) {
			em.remove(findedPperson);
		}
	}
}