package service;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import beans.Person;

@Stateless
public class RechPer {
	@PersistenceContext(unitName = "myTestDatabaseUnit")
    private EntityManager em;
	
	 public List<Person> findPersonsBynom(String nom) {
	        TypedQuery<Person> q = em.createQuery("FROM Person p where p.nom LIKE :name", Person.class);
	    	q.setParameter("name",nom);
	        return q.getResultList();
	    }
	 
	 public List<Person> findPersonsByprenom(String prenom) {
	        TypedQuery<Person> q = em.createQuery("FROM Person p where p.prenom LIKE :name", Person.class);
	    	q.setParameter("name",prenom);
	        return q.getResultList();
	    }
	 
	
		public List<Person> findPersonsByAct(String act) {
			Query query = null;
			try {
				query = em.createQuery("SELECT DISTINCT p FROM Activity a, Person p WHERE a.titre LIKE'%" + act + "%' AND p.id = a.owner.id");
			} catch (NoResultException e) {
				return null;
			}
			if (query != null) {
				return query.getResultList();
			}
			return null;
		}
}
