package service;

import java.util.List;

import javax.ejb.Stateful;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import beans.Activity;
import beans.Person;

@Stateful
public class ServiceActivity {
	
    @PersistenceContext(unitName = "myData")
    private EntityManager em;
    
    public Activity addActivity(Activity act) {
        em.persist(act);
        System.err.println("addActivity witdh id=" + act.getId());
        return (act);
    }
    public void removeAct(Activity act) {
    	em.remove(em.contains(act) ? act : em.merge(act));
    }
    public Activity updateAct(Activity act) {
        act = em.merge(act);
        return act;
    }
    
    //public List<Activity> findAllActivitys(long p) {
    //    TypedQuery<Activity> q = em.createQuery("FROM Activity", Activity.class);
    //    return q.getResultList();
   // }
    
	public List<Activity> findAllActivitys(long person) {
		Query query = null;
		

			try {
				query = em.createQuery("SELECT a FROM Activity a WHERE a.owner.Id=" + person + "");
			} catch (Exception e) {
			}
			if (query != null) {
				return query.getResultList();
			}
		
		return null;
	}
	public Activity findActivityByID(long id) {
    	return em.find(Activity.class, id);
    }

}
