package service;

import javax.ejb.Stateful;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import beans.Person;

@Stateful
public class SerAuth {

	@PersistenceContext(unitName = "myTestDatabaseUnit")
    private EntityManager em;
	
	public boolean Auth(String email,String pswd) {
		TypedQuery<Person> q = em.createQuery("FROM Person p WHERE p.email LIKE :email and p.pwd LIKE :pswd", Person.class);
    	q.setParameter("email",email);
    	q.setParameter("pswd",pswd);
         if(q.getResultList().isEmpty()) {
        	 return false;
         }else {
        	 return true;
         }
	}
	
	
}
