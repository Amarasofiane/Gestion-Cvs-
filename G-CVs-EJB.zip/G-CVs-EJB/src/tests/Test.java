package tests;

import java.util.Date;
import java.util.Set;

import javax.ejb.embeddable.EJBContainer;
import javax.naming.NamingException;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;


import beans.Activity;
import beans.Cv;
import beans.Person;
import service.SerAuth;
import service.ServicePerson;

public class Test {

    static EJBContainer container;
    static ServicePerson dao;
    static SerAuth auth;
	 Set<Activity> act;
	 int i = 1;

    @BeforeClass
    public static void beforeAll() throws NamingException {
        final String name = "java:global/JSFF/Service";
        final String name1 = "java:global/JSFF/SerAuth";

        container = EJBContainer.createEJBContainer();
        dao = (ServicePerson) container.getContext().lookup(name);
        auth = (SerAuth) container.getContext().lookup(name1);

    }

    @AfterClass
    public static void afterAll() {
        container.close();
    }

    @Before
    public void beforeTest() {
  
        }

    @After
    public void afterTest() {
        // pour plus tard
    }

    @org.junit.Test
    public void testInject() {
    	for(int i=0;i<100;i++) {
        Person p=new Person("amara","Sofiane","amara@aptidone.com","www.sofiane.com",new Date(),"marseille19");
        Cv cv=new Cv();
        p.setCvn(cv);
        Assert.assertNotNull(dao.addPerson(p));}
    	
    }
   @org.junit.Test
   public void testAuth() {
	   Assert.assertNotNull(auth.Auth("amara", "Sofiane"));
   }

}